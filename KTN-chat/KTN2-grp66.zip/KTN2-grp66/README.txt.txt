KTN2 project in TTM4100 for group 66.

Included are two clients, one in go and on in python, a server wirtten in python and the updated system documentation from KTN1.